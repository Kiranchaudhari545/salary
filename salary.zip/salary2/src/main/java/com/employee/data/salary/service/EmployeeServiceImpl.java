package com.employee.data.salary.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.data.salary.dao.EmployeeRepository;
import com.employee.data.salary.entity.Employee;


@Service
public class EmployeeServiceImpl implements EmployeeService {

	
	private EmployeeRepository employeeRepository;
	
     @Autowired	
	 public EmployeeServiceImpl(EmployeeRepository theEmployeeRepository) {
		
		 employeeRepository=theEmployeeRepository;
	}
	
	@Override
	public List<Employee> findAll() {
		
		return employeeRepository.findByOrderBySalaryDesc();
	}

	@Override
	public void save(Employee theEmployee) {
		
		employeeRepository.save(theEmployee);

	}

}
