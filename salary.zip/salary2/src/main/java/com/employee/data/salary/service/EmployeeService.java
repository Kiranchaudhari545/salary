package com.employee.data.salary.service;

import java.util.List;

import com.employee.data.salary.entity.Employee;

public interface EmployeeService {
	
	public List<Employee> findAll();
	
	public void save(Employee theEmployee);

}
